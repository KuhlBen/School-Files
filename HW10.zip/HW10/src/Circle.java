public class Circle extends GeometricThing implements Comparable<Circle>{
    private double radius;

    public Circle() {
    }

    public Circle(double radius) {
        super("red", false);
        this.radius = radius;
    }

    /** Return radius */
    public double getRadius() {
        return radius;
    }

    /** Set a new radius */
    public void setRadius(double radius) {
        this.radius = radius;
    }

    @Override /** Return area */
    public double getArea() {
        return radius * radius * Math.PI;
    }

    /** Return diameter */
    public double getDiameter() {
        return 2 * radius;
    }

    @Override /** Return perimeter */
    public double getPerimeter() {
        return 2 * radius * Math.PI;
    }

    /* Print the circle info */
    public void printCircle() {
        System.out.println("The circle is created " + getDateCreated() +
                " and the radius is " + radius);
    }

    @Override
    public boolean equals(Object o){
        if (this.radius == ((Circle)o).radius)
            return true;
        else
            return false;
    }

    @Override
    public int compareTo(Circle c) {
        if (this.radius > c.radius)
            return 1;
        else if (this.radius == c.radius)
            return 0;
        else
            return -1;
    }


}
