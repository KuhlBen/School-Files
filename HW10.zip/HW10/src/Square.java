/* Create a class Square that is a child
   of the abstract class GeometricObect.

   Square
   - side : double   //default value of 1.0
   +Square()   //sets side to default of 1.0
   +Square(side : double)   //sets property side to parameter side.
   +getSide() : double  //returns the property side.
   +toString() : String  //returns a string that describes the side value.

   */
public class Square extends GeometricThing {
    private double side;

    public Square() {
        side = 1;
    }

    public Square(double side) {
        this.side = side;
    }

    public double getSide() {
        return side;
    }

    public String toString() {
        return "Side: " + side + " Area: " + getArea() + " Perimeter: " + getPerimeter();
    }

    @Override // Return area
    public double getArea() {
        return side * side;
    }

    @Override // Return perimeter
    public double getPerimeter() {
        return 4 * side;
    }
}
