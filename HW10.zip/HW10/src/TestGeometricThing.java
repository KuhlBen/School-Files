//Ben Kuhlman
//Test File for hw10
import java.util.ArrayList;
import java.util.*;

public class TestGeometricThing {
    /** Main method */
    public static void main(String[] args) {
        // Declare and initialize two geometric objects
        GeometricThing geoThing1 = new Circle(5);
        GeometricThing geoThing2 = new Rectangle(5, 3);
        GeometricThing geoThing3 = new Square(5);

        System.out.println("The two objects have the same area? " +
                equalArea(geoThing1, geoThing2));

        // Display circle
        System.out.println("Circle");
        displayGeometricThing(geoThing1);

        // Display rectangle
        System.out.println("Rectangle");
        displayGeometricThing(geoThing2);

        // Display square
        System.out.println("Square");
        displayGeometricThing(geoThing3);

        System.out.println("Do circle and rectangle have same area? " +
                equalArea(geoThing1, geoThing3));


        //part 2
        ArrayList<GeometricThing> shapeList = new ArrayList<GeometricThing>();
        shapeList.add(geoThing1);
        shapeList.add(geoThing2);
        shapeList.add(geoThing3);

        System.out.println(sumArea(shapeList));

        //part 3
        shapeList.add(new Square(14));
        shapeList.add(new Rectangle(5,10));
        shapeList.add(new Circle(6));
        System.out.println("The biggest GeometricThing has an area of: "+ findBiggestThing(shapeList).getArea());

        //part 4
        Circle c1 = new Circle(4);
        Circle c2 = new Circle(7);
        Circle c3 = new Circle(2);
        Circle[] circleList = new Circle[3];
        circleList[0] = c1;
        circleList[1] = c2;
        circleList[2] = c3;
        java.util.Arrays.sort(circleList);
        System.out.println("circleArrayList in order: ");
        for(int i = 0; i < circleList.length; i++){
            circleList[i].printCircle();
        }
    }

    /** A method for comparing the areas of two geometric objects */
    public static boolean equalArea(GeometricThing object1,GeometricThing object2) {
        return object1.getArea() == object2.getArea();
    }

    /** A method for displaying a geometric object */
    public static void displayGeometricThing(GeometricThing object) {

        System.out.println("The area is " + object.getArea());
        System.out.println("The perimeter is " + object.getPerimeter());
        System.out.println();

    }
    public static double sumArea(ArrayList<GeometricThing> list){
        double total = 0;
        for (int i = 0; i < list.size(); i++){
            GeometricThing x = list.get(i);
            double area = x.getArea();
            total += area;
        }
        return total;
    }

    public static GeometricThing findBiggestThing(ArrayList<GeometricThing> list){

        int counter = 0;

        for(int i = 0; i < list.size(); i++){
            if(list.get(i).getArea() >= list.get(counter).getArea())
                counter = i;
        }
        return list.get(counter);
    }



}
