#CS1030
#Name: Ben Kuhlman
#700: 725708
#Problem 1.3
#Write a program that displays a pattern that spells out FUN

print("FFFFFFF   U     U   NN    NN")
print("FF        U     U   NNN   NN")
print("FFFFFFF   U     U   NN N  NN")
print("FF         U   U    NN  N NN")
print("FF          UUU     NN   NNN")
