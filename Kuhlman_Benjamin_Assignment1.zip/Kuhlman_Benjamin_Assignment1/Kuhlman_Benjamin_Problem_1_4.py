#CS1030
#Name: Ben Kuhlman
#700: 725708
#Problem 1.4
#Write a program that displays what a to the x power is

print("a      a^2     a^3")
print("1      1       1")
print("2      4       8")
print("3      9       27")
print("4      16      64") 
