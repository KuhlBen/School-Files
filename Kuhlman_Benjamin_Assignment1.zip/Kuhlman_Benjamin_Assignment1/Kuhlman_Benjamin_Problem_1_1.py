#CS1030
#Name: Ben Kuhlman
#700: 725708
#Problem 1.1
#Write a program that displays three messages

print("Welcome to Python")
print("Welcome to Computer Science")
print("Programming is fun")
