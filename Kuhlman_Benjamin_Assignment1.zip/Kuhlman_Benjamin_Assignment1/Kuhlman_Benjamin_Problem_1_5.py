#CS1030
#Name: Ben Kuhlman
#700: 725708
#Problem 1.5
#Write a program that computes an expression and displays the result

print("The result of the expression in the book is: ") #let the user know what to expect
print(((9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5))) #The result
