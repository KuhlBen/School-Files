#CS1030
#Name: Ben Kuhlman
#700: 725708
#Problem 1.8
#Write a program that displays the area and perimeter of a
#circle with a radius of 5.5

#Import math library for PI
import math

radius = 5.5

print("The area is: ")
print((5.5 * 5.5 * math.pi))
print() #Blank line to look better
print("The perimeter is: ")
print((2 * radius * math.pi))
