#CS1030
#Name: Ben Kuhlman
#700: 725708
#Problem 1.2
#Write a program that displays "Welcome to Python" 5 times

print("Welcome to Python")
print("Welcome to Python")
print("Welcome to Python")
print("Welcome to Python")
print("Welcome to Python")
