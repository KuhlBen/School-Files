//Ben Kuhlman
//Test for linear equation

import java.util.Scanner;
public class Problem_1_Test {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter A, B, C, D, E, and F: ");

        double a = input.nextDouble();
        double b = input.nextDouble();
        double c = input.nextDouble();
        double d = input.nextDouble();
        double e = input.nextDouble();
        double f = input.nextDouble();

        LinearEquation one = new LinearEquation(a,b,c,d,e,f);

        one.isSolvable();
}
}
