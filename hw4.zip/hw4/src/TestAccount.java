//Ben Kuhlman
//Test Account class problem 2
import java.util.Scanner;
public class TestAccount {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Account[] test = new Account[10];

        for (int i = 0; i<10; i++){
            test[i] = new Account(i, 100);
        }

        int count = -1;
        do{

            System.out.println("Please enter ID: ");
            int id = input.nextInt();
            if ((id > 9) || (id < 0)){
                System.out.println("Invalid ID. Goodbye.");
            }
            else {
                do{
                    displayMenu();
                 count = input.nextInt();
                 switch(count) {
                     case 1:
                         System.out.println("Your balance is: $" + test[id].getBalance());
                         System.out.println();
                         break;
                     case 2:
                         System.out.println("Enter amount to withdraw: ");
                         double amt = input.nextDouble();
                         test[id].withdraw(amt);
                         System.out.println();
                         break;
                     case 3:
                         System.out.println("Enter amount to deposit: ");
                         double num = input.nextDouble();
                         test[id].deposit(num);
                         System.out.println();
                         break;
                     case 4:
                         break;
                     default:
                         System.out.println("Invalid Input, try again.");
                         System.out.println();
                         break;
                 }
                }while(count!=4);
            }



        }while (true);


    }

   // ----------------------------------------------------------------

    public static void displayMenu(){
        System.out.println("Main Menu");
        System.out.println("1:Check Balance");
        System.out.println("2:Withdraw");
        System.out.println("3:Deposit");
        System.out.println("4:Exit");
        System.out.println("Enter a choice: ");
    }
}
