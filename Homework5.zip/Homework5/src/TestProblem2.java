//Ben Kuhlman
//This program tests StringBuilder and swaps the capitalization of a string
import java.util.Scanner;
public class TestProblem2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Please enter a string: ");
        String s = input.nextLine();
        System.out.print("The new string is: "+ StringBuilderProblem.swapCase(s));




    }
}
