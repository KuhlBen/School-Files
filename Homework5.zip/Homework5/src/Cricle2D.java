//Ben Kuhlman
//Problem 1, create a class that creates circles and has
//methods to find the location of the circle and find overlaps
class Circle2D {
    private double x = 0;
    private double y = 0;
    private double radius = 1;

    public Circle2D(){}
    public Circle2D(double x, double y, double radius){
        this.x=x;
        this.y=y;
        this.radius=radius;
    }

    public double getX(){return x;}
    public double getY(){return y;}
    public double getRadius(){return radius;}
    public double getArea(){return (radius*radius*Math.PI);}
    public double getPerimeter(){return (2*Math.PI*radius);}

    private double distance(double x1, double y1, double x2, double y2){
        return Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
    }

    public boolean contains(double x, double y){
        if (distance(this.x,this.y, x, y) <= this.radius)
            return true;
        else
            return false;
    }

    public boolean contains(Circle2D circle){
        if(((distance(this.x, this.y, circle.x, circle.y)+circle.radius) <= (this.radius)))
            return true;
        else return false;
    }

    public boolean overlaps(Circle2D circle){
        if((distance(this.x, this.y, circle.x, circle.y) <= circle.radius + this.radius))
            return true;
        else return false;
    }

}
