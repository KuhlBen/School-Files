//Ben Kuhlman
//The swapCase method for the String Builder that changes the casing
public class StringBuilderProblem {
    public String s;
    public StringBuilderProblem(String s1){}


    public static String swapCase(String s){
        StringBuilder str = new StringBuilder(s);
        String temp;
        for(int i = 0; i < s.length(); i++){
           char c = s.charAt(i);
            if(Character.isUpperCase(c)) {
                c = Character.toLowerCase(c);
                str.setCharAt(i, c);
            }

            else if (Character.isLowerCase(c)) {
                c = Character.toUpperCase(c);
                str.setCharAt(i, c);


            }
        }



        temp = str.toString();
        return temp;
    }




    /*public static void swapCaseVoid(String s){
        char[] c = new char[s.length()];
        for(int i = 0; i < s.length(); i++){
            c[i] = s.charAt(i);
            if((c[i] <= 'z')&&(c[i] >= 'a')) {
                c[i] -= 32;
            }
            else if ((c[i] <= 'Z')&&(c[i] >= 'A'))
                c[i] += 32;

        }


        for(int i = 0; i < s.length(); i++)
            System.out.print(c[i]);

    }*/


}
