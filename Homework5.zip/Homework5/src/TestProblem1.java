//Ben Kuhlman
//This program tests Circle2D with predetermined values
public class TestProblem1 {
    public static void main(String[] args) {


        Circle2D c1 = new Circle2D(2,2,5.5);

        System.out.println("c1 area: "+c1.getArea()+ "\nc1 perimeter: "+c1.getPerimeter());


        if(c1.contains(3,3)==true)
            System.out.println("The points (3,3) are within c1");
        else
            System.out.println("The points (3,3) are not within c1");

        if (c1.contains(new Circle2D(4,5,10.5))==true)
            System.out.println("The new circle, c2, is contained in c1");
        else
            System.out.println("The new circle, c2, is not contained in c1");

        if (c1.overlaps((new Circle2D(3, 5, 2.3)))==true)
            System.out.println("c1 and c2 overlap");
        else
            System.out.println("c1 and c2 do not overlap");
    }
}
