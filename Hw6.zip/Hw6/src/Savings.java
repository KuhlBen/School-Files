//Ben Kuhlman
//the class savings that utilizes class account as a parent
class Savings extends Account {

    public Savings(int id, double balance){
        super(id,balance);
    }
    
    public void withdraw(double amt){
        if ((getBalance() - amt) < 0)
            System.out.println("Insufficient funds");
        else
            super.withdraw(amt);
    }

    public String tooString(){return "ID: "+getId()+"\nBalance: $"+getBalance()+"\nInterest Rate: "+getAnnualInterestRate()+"\nDate Created: "+getDateCreated();}

}
