//Ben Kuhlman
//Account class from hw4 that is parent of checking and savings
import java.util.Date;

public class Account {

        private int id;
        private double balance;
        private double annualInterestRate;
        private java.util.Date dateCreated;

        public Account(){
            dateCreated = new java.util.Date();
        }
        public Account(int someId, double someBalance){
            id = someId;
            balance = someBalance;
            dateCreated = new java.util.Date();

        }
        public int getId(){
            return id;
        }
        public void setId(int newId){
            id = newId;
        }
        public double getBalance(){
            return balance;
        }
        public void setBalance(double newBalance){
            balance = newBalance;
        }
        public double getAnnualInterestRate(){
            return annualInterestRate;
        }
        public void setAnnualInterestRate(double newRate){
            annualInterestRate = newRate;
        }
        public Date getDateCreated(){
            return dateCreated;
        }
        public double getMonthlyInterestRate(){
            return (annualInterestRate/100)/12;
        }
        public double getMonthlyInterest(){
            return balance * getMonthlyInterestRate();
        }
        public void withdraw(double amt){
            balance -= amt;
        }
        public void deposit(double amt){
            balance += amt;
        }

        public String toString(){return "ID: "+getId()+"\nBalance: $"+getBalance()+"\nInterest Rate: "+getAnnualInterestRate()+"\nDate Created: "+getDateCreated();}
}
