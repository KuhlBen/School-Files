//Ben Kuhlman
//class checking utilizes class Account to create a checking account
class Checking extends Account{
    private double overDraft;

    public Checking(int id, double balance, double overDraft){
        super(id, balance);
        this.overDraft = overDraft;
    }


    public void withdraw(double amt){
        if ((getBalance()- amt) > 0)
            super.withdraw(amt);
        else if ((getBalance()- amt + 100 - overDraft) > 0){
            System.out.println("Overdrawn, enacting overdraft");
            overDraft = amt - getBalance();
            super.setBalance(0);
        }
        else
            System.out.println("Insufficient funds");
    }
    public double getOverDraft(){return overDraft;}

    public String tooString(){return "ID: "+getId()+"\nBalance: $"+getBalance()+"\nInterest Rate: "+getAnnualInterestRate()+"\nDate Created: "+getDateCreated()+"\nOverdrawn by: $"+getOverDraft();}

}
