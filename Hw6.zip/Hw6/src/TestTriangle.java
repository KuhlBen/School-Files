//Ben Kuhlman
//This program test the class triangle with user input
import java.util.Scanner;
public class TestTriangle {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter 3 doubles for sides, a color, and whether the triangle is filled or not.");
        double side1 = input.nextDouble();
        double side2 = input.nextDouble();
        double side3 = input.nextDouble();
        input.nextLine();
        String color = input.nextLine();
        boolean fill = input.nextBoolean();
        Triangle test = new Triangle(side1,side2,side3,color,fill);
        System.out.println();
        System.out.println("Area: "+ test.getArea());
        System.out.println("Perimeter: "+test.getPerimeter());
        System.out.println("Color: "+test.getColor());
        System.out.println("The triangle is filled: "+test.isFilled());
        System.out.println(test.toString());

    }
}
