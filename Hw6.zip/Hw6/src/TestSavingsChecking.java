//Ben Kuhlman
//the file that will run and test Checking and Savings
public class TestSavingsChecking {
    public static void main(String[] args) {
        Savings jon = new Savings(123, 10000);
        Checking sam = new Checking(456,300,0);

        //testing savings
        jon.deposit(200);
        System.out.println("New Balance: $ "+jon.getBalance());
        jon.setAnnualInterestRate(5);
        System.out.println("Monthly Interest: $"+ jon.getMonthlyInterest());
        jon.withdraw(8000);
        System.out.println("New Balance: $ "+jon.getBalance());
        System.out.println("attempting to withdraw past 0");
        jon.withdraw(2222);
        System.out.println(jon.getBalance());
        System.out.println();
        System.out.println("Savings account jon to string: ");
        System.out.println(jon.tooString());
        System.out.println();

        //testing checking
        System.out.println("Checking Balance: $" + sam.getBalance());
        sam.deposit(200);
        sam.setAnnualInterestRate(1);
        System.out.println("Monthly Interest: $"+ sam.getMonthlyInterest());
        System.out.println("New Balance: $" + sam.getBalance());
        sam.withdraw(400);
        System.out.println("New Balance: $" + sam.getBalance());
        System.out.println("Attempting to go past 0");
        sam.withdraw(150);
        System.out.println("New Balance: $" + sam.getBalance());
        System.out.println("Checking if overdrawn");
        System.out.println("Overdrawn by: $"+sam.getOverDraft());
        System.out.println("Attempting to go past the threshold of 100");
        sam.withdraw(51);
        System.out.println("New Balance: $"+ sam.getBalance());
        System.out.println("Overdrawn by: $"+sam.getOverDraft());

        System.out.println();
        System.out.println("Checking account sam to string");
        System.out.println(sam.tooString());

    }
}
