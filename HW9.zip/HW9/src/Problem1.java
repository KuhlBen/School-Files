//Ben Kuhlman
//The ArrayIndexOutOfBoundsException Problem
import java.util.Scanner;
public class Problem1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] list = new int[100];
        //fills the array
        for (int i = 0; i<100; i++){
            list[i] = (int)(Math.random()*10)+1;
            //System.out.println(list[i]);
        }

        //allow the user to check an index
        System.out.println("Enter 0-99 to check what's at that index of the array: ");

        try{
            int num = input.nextInt();
            System.out.println("The index at "+ num+" is "+ list[num]);
        }
        catch (ArrayIndexOutOfBoundsException ex){
            System.out.println("Out Of Bounds");
        }
    }
}
