import java.util.Arrays;

//Ben Kuhlman
//This program sorts arrays and finds the biggest num in an Integer array
public class Hw7Main {
    public static void main(String[] args) {
        int[] array = {21, 75, 34, 35, 99, 42, 68, 67, 72, 82};     //should return  -   21, 75, 35, 99, 67, 34, 42, 68, 72, 82
        Integer[] array2 = {10,20,30,40,50};
        int[] array2_2 = {10,20,30,40,50};

        System.out.println("The first array is: "+ Arrays.toString(array));
        System.out.println("Is it sorted?: "+ isSorted(array));
        System.out.println("The first array sorted from odd to even: ");
        array = rearrangeIt(array);
        System.out.println(Arrays.toString(array));
        System.out.println("The max value in the second array is: "+ findMax(array2));
        System.out.println("Is array 2 sorted?: " + isSorted(array2_2));


    }
    //public static int[] temp = new int[10];
    public static int[] rearrangeIt(int[] array){
        int temp[] = new int[array.length];
        int position = 0;
        int temporary = 0;

        for (int i = 0; i< array.length; i++){
            if ((array[i] > temp[position]) &&  (array[i] % 2 == 1)) {
                temp[position] = array[i];
                position++;
            }
        }

        for (int i = 0; i< array.length; i++){
            if ((array[i] > temp[position]) &&  (array[i] % 2 == 0)) {
                temp[position] = array[i];
                position++;
            }
        }



        return temp;
    }

    public static boolean isSorted(int[] list){
        boolean sorted = true;
        for(int i = 0; i < list.length - 1; i++){
            if (list[i] > list[i+1])
                sorted = false;
        }
        return sorted;
        }




    public static Integer findMax(Integer[ ] list){
        Integer max = 0;
        //Integer[] array2 = {10,20,30,40,50};

        for(int i  = 0; i < list.length; i++){
            if(list[i] > max)
                max = list[i];
        }

        return max;
    }
}
