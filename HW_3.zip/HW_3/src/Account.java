//Ben Kuhlman
//Problem 1 - create a bank account with private data fields
import java.util.Date;
public class Account {
    private int id = 0;
    private double balance = 0;
    private static double annIntRate = 0;
    private java.util.Date dateCreated;

    public Account(){} //no arg constructer

    public Account(int someId, double someBalance){ //arg constructer
    id = someId;
    balance = someBalance;
    dateCreated = new Date();
    }

    public int getId(){return id;}

    public void setId(int newId){ id = newId;}

    public double getBalance(){return balance;}

    public void setBalance(double newBal){balance = newBal;}

    public double getAnnIntRate(){return annIntRate;}

    public void setAnnIntRate(double newRate){annIntRate = newRate;}

    public Date getDateCreated(){return dateCreated;}

    public Double getMonthlyIntRate(){return (annIntRate/1200);}

    public double getMonthlyInterest(){return (balance*getMonthlyIntRate());}

    public void withdraw (double amt){balance = balance - amt;}

    public void deposit(double amt){balance = balance + amt;}
}
