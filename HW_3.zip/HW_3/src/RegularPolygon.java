public class RegularPolygon {
    private int n = 3; //number of sides
    private double side = 1; //side length
    private double x = 0; //polygon's center x-axis
    private double y = 0; //polygon's center y-axis

    RegularPolygon(){}      //no arg constructor

    RegularPolygon(int sides, double length){ n = sides; side = length;}

    RegularPolygon(int sides, double length, double axisX, double axisY){n = sides; side = length; x = axisX; y = axisY;}

    public int getN(){return n;}
    public void setN(int sides){n=sides;}

    public double getSide(){return side;}
    public void setSide(double num){side = num;}

    public double getX(){return x;}
    public void setX(double a){x = a;}

    public double getY(){return y;}
    public void setY(double b){y = b;}

    public double getPerimeter(){return (side*n);}

    public double getArea(){return ((n*side*side)/(Math.tan(Math.PI/n)*4));}
}
