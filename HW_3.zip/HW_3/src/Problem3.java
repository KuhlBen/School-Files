//Ben Kuhlman
//resort an array into order
public class Problem3 {
    public static void main(String[] args) {
        int[] array = new int[10];

        //declared variables
        int lastIndexTaken = 5;
        int num = 7;

        int count =2;
        for (int i = 0;i < 6; i++){         //establish the array
            array[i] = count;
            count+=2;
        }
        int temp = -1;
        for(int i = 0; i < 10; i++){
            if (array[i] > num){
                temp = array[i];
                array[i] = num;
                num = temp;
            }
            else if (array[i]==0) {
                array[i] = num;
                break;
            }

        }

        for (int i = 0; i <array.length; i++) {
            System.out.println("array[" + i + "]   " + array[i]);
        }

    }
}
