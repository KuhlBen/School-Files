import java.util.Scanner;
public class HolidayMethod {
    public static void HolidayExecute() {
        Scanner input = new Scanner(System.in);
        //temp variables for the loop
        String Holiday;
        String senderName;
        String senderEmail;
        String receiver;
        String receiverEmail;
        String sig; //signature
        HolidayGreeting.numCards = 0;
        int gift;
        int fam = 0;
        int total;  //size of array
        int goBack; //variable to go back and edit a ThankYouCard
        int choice = 0;

        System.out.print("How many Holiday Greeting Cards will you be sending?: ");
        total = input.nextInt();
        HolidayGreeting[] list = new HolidayGreeting[total];
        input.nextLine();


        System.out.print("Let's make an electronic Holiday Greeting. Please start by entering your name: ");
        senderName = input.nextLine();
        System.out.print("Next, enter your email: ");
        senderEmail = input.nextLine();
        System.out.print("Next, we need to know what holiday you are sending a greeting for: ");
        Holiday = input.nextLine();
        System.out.print("Is this card from just you or your whole family, 0 for you 1 for the whole family: ");
        fam = input.nextInt();
        if (fam == 0) {
            HolidayGreeting.family = false;
        } else {
            HolidayGreeting.family = true;
            input.nextLine();
            System.out.print("Enter your last name: ");
            HolidayGreeting.lastName = input.nextLine();
        }
        System.out.print("Would you like to provide a signature for all of your emails? 0 for no 1 for yes: ");
        choice = input.nextInt();
        if (choice == 1) {
            System.out.print("Enter your signature: ");
            input.nextLine();
            sig = input.nextLine();
            Email.signature = sig;
            System.out.println(sig);
        } else {
            Email.signature = senderName;
        }


        for (int i = 0; i < total; i++) {
            input.nextLine();
            System.out.print("Next, enter in the name of the person receiving the Greeting: ");
            receiver = input.nextLine();
            System.out.print("Next, we will need " + receiver + "'s email: ");
            receiverEmail = input.nextLine();

            System.out.print("Would you like to include a gift? 0 for no 1 for yes: ");
            gift = input.nextInt();
            if (gift == 0) {
                HolidayGreeting.holidayGift = false;
            } else {
                HolidayGreeting.holidayGift = true;
                input.nextLine();
                System.out.print("Enter your gift amount: ");
                HolidayGreeting.giftAmount = input.nextDouble();
            }


            //create the first greeting
            list[i] = new HolidayGreeting(Holiday, HolidayGreeting.family, senderName, senderEmail, receiver, receiverEmail, HolidayGreeting.signature, HolidayGreeting.holidayGift);
            System.out.println();
            list[i].getCardBody();
            System.out.println();
        }
    }
}

