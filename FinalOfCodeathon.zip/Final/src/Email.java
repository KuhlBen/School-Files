public class Email {
    //Variables
    public static String sender;
    public static String senderEmail;
    private String recipient;
    private String recipientEmails;
    public static String signature;
    boolean frontofCards;
    private String subject;

    //Constructor
    public Email(){}
    public Email(String sender1, String senderEmail1, String recipient, String recipientEmails, String signature1){
        sender = sender1;
        senderEmail = senderEmail1;
        this.recipient = recipient;
        this.recipientEmails = recipientEmails;
        signature = signature1;
    }

    public Email(String recipient, String recipientEmail){
        this.recipient = recipient;
        this.recipientEmails = recipientEmail;
    }

    //Methods
    public String getSender() {
        return sender;
    }

    public void setSender(String sender1) {
        sender = sender1;
    }

    public String getSenderEmail() {
        return senderEmail;
    }

    public void setSenderEmail(String senderEmail1) {
        senderEmail = senderEmail1;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getRecipientEmails() {
        return recipientEmails;
    }

    public void setRecipientEmails(String recipientEmails) {
        this.recipientEmails = recipientEmails;
    }

    public String getEmailBody(){return "This is a default email body!";}

    public boolean getFrontofCard(){return frontofCards = true;}
    public boolean getBackofCard(){return frontofCards = false; }
}

