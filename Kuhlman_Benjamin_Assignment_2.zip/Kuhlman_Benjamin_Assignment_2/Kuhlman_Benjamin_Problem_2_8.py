#CS1030
#Name: Ben Kuhlman
#700: 725708
#Assignment 2 / Problem 2.8
#Description:
'''
Step 1:
Get 3 values from user for mass, initial temp, and final temp

Step 2:
calculate the the energy needed to heat up the water in joules

Step 3:
display the results
'''

#Prompt the user for the 3 values
weight = eval(input("Enter the amount of water in kilograms: "))
initialTemp = eval(input("Enter the initial temperature in Celcius: "))
finalTemp = eval(input("Enter the final temperature in Celcius: "))

#Calculate the required energy
energy = weight * (finalTemp - initialTemp) * 4184

#Display the results
print(f"The energy needed is {energy} joules")
