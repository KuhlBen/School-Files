#CS1030
#Name: Ben Kuhlman
#700: 725708
#Assignment 2 / Problem 2.16
#Description:
'''
Step 1:
Get 3 values from user for starting velocity, ending velocity,
and time in seconds

Step 2:
calculate the velocity with given formula

Step 3:
display the results
'''

#Prompt the user for the 3 values
startVel = eval(input("Enter the starting velocity: "))
endVel = eval(input("Enter the ending velocity: "))
time = eval(input("Enter the time span in seconds: "))

#Compute the average acceleration
acceleration = round(((endVel - startVel) / time), 4)

#Display the results
print(f"The average acceleration is {acceleration}")
