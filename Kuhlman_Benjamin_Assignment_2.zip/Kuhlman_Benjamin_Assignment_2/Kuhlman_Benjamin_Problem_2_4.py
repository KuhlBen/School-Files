#CS1030
#Name: Ben Kuhlman
#700: 725708
#Assignment 2 / Problem 2.4
#Description:
'''
Step 1:
Get a value from the user for pounds

Step 2:
convert the pounds to kilograms

Step 3:
display the results
'''

#Prompt the user to input value for pounds
pound = eval(input("Enter a value for pounds: "))

#Convert pounds to kilograms
kilo = pound * .454

#Display the results
print(f"{pound} pounds is {kilo} kilograms")
