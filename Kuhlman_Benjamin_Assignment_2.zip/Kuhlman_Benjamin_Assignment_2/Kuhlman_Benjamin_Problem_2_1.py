#CS1030
#Name: Ben Kuhlman
#700: 725708
#Assignment 2 / Problem 2.1
#Description: Convert celsius to fahrenehit
'''
Step 1:
Get a value from the user for the variable celsius

Step 2:
Calculate the fahrenheit with the given formula

Note: Place the formula inside the description

Step 3: display our results
'''

#Prompt the user to enter a value for celsius
celsius = eval(input("Enter a degree in Celsius: "))

#Compute the conversion
fahrenheit = (9/5) * celsius + 32

print(f"{celsius} degrees celsius is {fahrenheit} degrees in fahrenheit")
