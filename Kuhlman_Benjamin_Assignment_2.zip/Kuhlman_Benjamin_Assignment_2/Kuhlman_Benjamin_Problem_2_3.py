#CS1030
#Name: Ben Kuhlman
#700: 725708
#Assignment 2 / Problem 2.3
#Description:
'''
Step 1:
Get values for feet

Step 2:
Calculate feet to meters

Step 3:
display the results
'''

#Prompt the user to input value for feet
feet = eval(input("Enter a value for feet: "))

#Calculate feet to meters
meters = feet * .305

#Display the results
print(f"{feet} feet is {meters} meters")
