#CS1030
#Name: Ben Kuhlman
#700: 725708
#Assignment 2 / Problem 2.6
#Description:
'''
Step 1:
Get a value from the user

Step 2:
extract the 4 digits and store them as seperate variables

Step 3:
display the results
'''

#Prompt the user to input a value
num = eval(input("Enter a number between 0 and 1000: "))

#Extract and remove the first digit
digit1 = num % 10 #Extracting the last digit
num //= 10 #remove the last digit

#Extract and remove the second digit
digit2 = num % 10
num //= 10

#Extract and remove the third digit
digit3 = num % 10
num //= 10

#Extrace the fourth digit
digit4 = num % 10

#Display the results
print(f"The sum of the digits is {digit1 + digit2 + digit3 + digit4}")
