#CS1030
#Name: Ben Kuhlman
#700: 725708
#Assignment 2 / Problem 2.5
#Description:
'''
Step 1:
Get a value for subtotal and gratuity rate from user

Step 2:
calculate the new total and the gratuity

Step 3:
display the results
'''

#Prompt the user to input value for subtotal
sub = eval(input("Enter a value for the subtotal: "))
rate = eval(input("Enter a value for the gratuity rate: ")) / 100

#Calculate the new total and gratuity
tip = round((sub * rate),2)
total = round((sub + tip),2)

#Display the results
print(f"The gratuity is {tip} and the total is {total}")
