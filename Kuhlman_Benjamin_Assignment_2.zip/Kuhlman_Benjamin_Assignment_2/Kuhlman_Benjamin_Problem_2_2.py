#CS1030
#Name: Ben Kuhlman
#700: 725708
#Assignment 2 / Problem 2.2
#Description:
'''
Step 1:
Get values for length and radius of cylinder

Step 2:
Compute the area and volume

Step 3:
display the results
'''

#Prompt the user to input values
radius = eval(input("Enter the radius of the cylinder: "))

length = eval(input("Enter the length of the cylinder: "))

#Compute the area and volume
area = radius * radius * 3.14159
volume = area * length

#Display the results
print(f"The area is {area}")
print(f"The volume is {volume}")
