#CS1030
#Name: Ben Kuhlman
#700: 725708
#Assignment 2 / Problem 2.7
#Description:
'''
Step 1:
Get a value for minutes from user

Step 2:
calculate the years and days in said minutes

Step 3:
display the results
'''

#Prompt the user to input value for subtotal
mins = eval(input("Enter a value for minutes: "))

#Calculate total days
totalDays = mins / 60 / 24

#Calculate years and days
years = (int) (totalDays / 365)
days = (int) (totalDays % 365)

#Display the results
print(f"{mins} minutes is approximately {years} years and {days} days")
