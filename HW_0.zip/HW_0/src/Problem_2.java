public class Problem_2 {
    public static void main(String[] args) {
        int[] array = new int[10];
        int[] list = new int[5];

        for(int i = 0; i < 10; i++){
            array[i] = (int)(Math.random()*5)+1;
        }

        for(int i = 0; i < 10; i++){
            if(array[i] == 1)
                list[0]++;
            else if(array[i] == 2)
                list[1]++;
            else if(array[i] == 3)
                list[2]++;
            else if(array[i] == 4)
                list[3]++;
            else if(array[i] == 5)
                list[4]++;
        }


        System.out.println("Number      Appears");


        for(int i = 0; i < 5; i++){
            System.out.println((i + 1)+ "           " + list[i]);
        }
    }
}
