import java.util.Scanner;

public class Problem_4 {
    public static void printMe1(char c, int n){
        for (int i = 0; i < n; i++){
            System.out.print(c);
        }

    }

    public static void printMe2(int someInt, int n){
        for(int i = 0; i < n; i++){
            System.out.print(someInt);
        }

    }

    public static void printMe3(double someDouble, char c, int n){
        for(int i = 0; i < n; i++){
            System.out.print(someDouble +""+ c);
        }

    }

    public static void printMe4(String s, int n){
            for(int i = 0; i < n; i++){
                System.out.print(s);
            }
    }

    public static void main(String[] args) {
        String s = "Hello World ";
        printMe1('a', 5);
        System.out.println();
        printMe2(5, 7);
        System.out.println();
        printMe3(1.3,'!', 4);
        System.out.println();
        printMe4(s, 6);
    }
}
