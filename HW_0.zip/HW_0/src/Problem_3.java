import java.util.Scanner;

public class Problem_3 {
    public static int lastIndexOf(int[] myArray, int value){

        int result = 10;
        for(int i = 0; i < 10; i++){
            if (value == myArray[i])
                result = i;
        }
        if (result == 10)
            result = -1;

        return result;
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int list[] = new int[10];
        System.out.print("Input 10 numbers: ");
        for(int i = 0; i < 10; i++){
            list[i] = input.nextInt();
        }

        System.out.print("Enter a number to search for: ");
        int num = input.nextInt();



        System.out.println("The last index of the value " + num + " is " + lastIndexOf(list, num));

    }
}
