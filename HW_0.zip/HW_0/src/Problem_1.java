import java.util.Scanner;

public class Problem_1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter name: ");
        String name = input.nextLine();

        System.out.print("Enter current age: ");
        int age = input.nextInt();

        System.out.print("Enter future year: ");
        int year = input.nextInt();


        int result = (year - 2022) + age;

        System.out.println(name + " will be " + result + " years old in the year " + year);

    }
}