//Ben Kuhlman
//Homework assignment that utilizes array lists, sorting, and union
import java.util.ArrayList;
import java.util.Scanner;
public class ArrayListHw8 {
    public static void main(String[] args) {

        //create the list with 5 Doubles
        Scanner input = new Scanner(System.in);
        ArrayList<Double> list = new ArrayList<>();

        System.out.println("Please enter 5 Doubles: ");
        for(int i = 0; i < 5; i++){
            list.add(input.nextDouble());
        }

        //Display the contents
        System.out.println(list.toString());
        //sort list
        java.util.Collections.sort(list);
        System.out.println(list.toString());
        //shuffle list
        java.util.Collections.shuffle(list);
        for(int i = 0; i < list.size(); i++){
            System.out.println(i+": "+ list.get(i));
        }
        //min and max
        System.out.println("The minimum value is: " + java.util.Collections.min(list));
        System.out.println("The maximum value is: " + java.util.Collections.max(list));

        //call and use removeDuplicates
        ArrayList<String> strings = new ArrayList<>();
        System.out.println("Please enter 10 Strings: ");
        for(int i = 0; i < 11; i++){
            strings.add(input.nextLine());
        }
        removeDuplicates(strings);

        //call and use union
        System.out.println("Let's create the first Integer list, input a 0 whenever your list is complete");
        int counter = 1;
        ArrayList<Integer> list1 = new ArrayList<>();
        for(int i = 1; counter != 0; i = counter){
            counter = input.nextInt();
            list1.add(counter);

        }
        //list2
        System.out.println("Let's create the second Integer list, input a 0 whenever your list is complete");
        counter = 1;
        ArrayList<Integer> list2 = new ArrayList<>();

        for(int i = 1; counter != 0; i = counter){
            counter = input.nextInt();
            list2.add(counter);
        }
        System.out.println("The union of list 1 and 2 is: "+union(list1,list2));

    }

    public static void removeDuplicates(ArrayList<String> list){
        ArrayList<String> strings = new ArrayList<>();

        for(int i = 0; i < list.size(); i++){
            if(strings.contains(list.get(i))){}
            else
                strings.add(list.get(i));

        }
        System.out.println("The distinct strings are: "/*+ strings.toString()*/);
        for(int i = 0; i < strings.size(); i++){
            System.out.println(strings.get(i));
        }

    }

    public static ArrayList<Integer> union(ArrayList<Integer> list1, ArrayList<Integer> list2){
        ArrayList<Integer> list3 = new ArrayList<>();

        for(int i = 0; i < list1.size(); i++){
            if(list3.contains(list1.get(i))){}
            else
                list3.add(list1.get(i));
        }

        for(int i = 0; i < list2.size(); i++){
            if(list3.contains(list2.get(i))){}
            else
                list3.add(list2.get(i));
        }
        java.util.Collections.sort(list3);
        list3.remove(0);

        return list3;
    }
}
