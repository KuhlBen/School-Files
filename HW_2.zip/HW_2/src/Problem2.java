public class Problem2 {
    public static void main(String[] args) {
        Rectangle rec1 = new Rectangle();
        System.out.println("The area of rec1 is "+ rec1.getArea()+ " and the perimeter is " + rec1.getPerimeter());

        Rectangle rec2 = new Rectangle(4, 40);
        System.out.println("The area of rec2 is "+ rec2.getArea()+ " and the perimeter is "+  rec2.getPerimeter());

        Rectangle rec3 = new Rectangle(3.5, 35.9);
        System.out.println("The area of rec3 is "+ rec3.getArea()+ " and the perimeter is " + rec3.getPerimeter());

    }
}
class Rectangle {


        double width = 1;
        double height = 1;

        Rectangle() {
        }

        Rectangle(double newWidth, double newHeight) {
            width = newWidth;
            height = newHeight;
        }

        double getArea() {
            return width * height;
        }

        double getPerimeter() {
            return ((width * 2) + (height * 2));
        }
}


