class shoes {
    String name;
    String color;
    String brand;
    boolean highTop;

    boolean isHighTop(){
        if (highTop==true) {
            System.out.println("These shoes are high tops.");
            return true;
        }
        else{
            System.out.println("These shoes are not high tops");
            return false;
        }
    }

    void getDirty(){
        System.out.println("Oh no the shoes are dirty!");
    }

    void getCleaned(){
        System.out.println("Look at how clean these shoes are now!");
    }

    void getPutOn(){
        System.out.println(name+ " has put the shoes on.");
    }
}
